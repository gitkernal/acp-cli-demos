# KERNAL Showcase — Tutorial Lengkap dari Awal sampai Selesai

Kondisi lo sekarang: PR #29 udah kebuka, tapi file `showcase.json` ke-taruh di lokasi salah (`kernal/` di root, harusnya `showcase/kernal/`). Maintainer @ytoast minta: (1) pindahin ke folder `showcase/`, (2) tambahin README.md.

Tutorial ini beresin semua itu sekaligus, plus masukin package lengkap (11 skills, examples, soul). Semua lewat GitHub web — ga perlu terminal / Claude Code. Estimasi 15 menit.

---

## FILE YANG AKAN DI-UPLOAD (16 file)

Semua ada di `kernal-showcase-files.zip`. Extract dulu di laptop. Struktur:
```
showcase.json
README.md
soul.md
examples/prompt.md
examples/result-redacted.md
skills/alpha-digest/SKILL.md
skills/wallet-digest/SKILL.md
skills/token-alert/SKILL.md
skills/gas-tracker/SKILL.md
skills/defi-monitor/SKILL.md
skills/arbitrage-scanner/SKILL.md
skills/sniper-signal/SKILL.md
skills/copy-trade-signal/SKILL.md
skills/yield-signal/SKILL.md
skills/rebalance-signal/SKILL.md
skills/mev-audit/SKILL.md
```

SEMUA ini nanti masuk ke `showcase/kernal/` di repo. Jadi hasil akhir di GitHub:
`showcase/kernal/showcase.json`, `showcase/kernal/README.md`, dst.

---

## LANGKAH 0 — Extract ZIP

1. Download `kernal-showcase-files.zip`
2. Klik kanan → Extract All (Windows) — jadi folder `kernal-showcase-files`
3. Buka foldernya, pastikan ada: showcase.json, README.md, soul.md, folder examples/, folder skills/

---

## LANGKAH 1 — Buka fork lo

1. Buka: **https://github.com/gitkernal/acp-cli-demos**
2. Pastikan lo di branch **main** (dropdown kiri atas, harusnya udah "main")

---

## LANGKAH 2 — HAPUS file yang salah lokasi

File lo ada di `kernal/showcase.json` (root). Kita hapus dulu.

1. Di halaman repo fork, cari folder **`kernal`** (di root, BUKAN di dalam `showcase`)
2. Klik masuk ke folder `kernal`
3. Klik file `showcase.json`
4. Klik ikon **tempat sampah** (Delete this file) di kanan atas
5. Scroll bawah → **Commit changes**
   - Commit message: `Remove misplaced showcase.json from root`
   - Klik **Commit changes**

> Kalau lo ga nemu folder `kernal` di root — mungkin lokasinya udah bener atau beda. Cek "Files changed" di PR #29 buat lihat path aslinya. Kalau udah di `showcase/kernal/`, skip langkah ini.

---

## LANGKAH 3 — Upload package lengkap ke showcase/kernal/

Sekarang upload semua file ke lokasi yang BENAR.

1. Di repo fork, klik masuk ke folder **`showcase`**
2. Klik tombol **Add file** (kanan atas) → **Upload files**
3. Di halaman upload, PENTING — lo harus atur supaya masuk ke sub-folder `kernal`:
   - Cara paling aman: drag folder-folder-nya, tapi karena GitHub upload ga bisa langsung bikin nested folder dari drag di semua browser, pakai cara ini:

**Cara upload yang pasti bener:**

GitHub upload preserve struktur folder kalau lo drag FOLDER-nya. Jadi:

a. Dari folder hasil extract, **buat dulu satu folder induk bernama `kernal`** di laptop lo, dan pindahin semua isi (showcase.json, README.md, soul.md, examples/, skills/) ke dalam folder `kernal` itu.

b. Sekarang lo punya:
```
kernal/
├── showcase.json
├── README.md
├── soul.md
├── examples/...
└── skills/...
```

c. Di halaman "Upload files" GitHub (yang lagi di dalam folder `showcase`), **drag folder `kernal`** itu ke area upload.

d. GitHub bakal upload semua isi dengan struktur `kernal/showcase.json`, `kernal/skills/...`, dst — karena lo lagi di dalam `showcase/`, hasilnya jadi `showcase/kernal/...` ✅

4. Scroll bawah → commit message: `Add complete KERNAL showcase package (manifest, 11 skills, README, examples, soul)`
5. Klik **Commit changes**

---

## LANGKAH 4 — Verifikasi struktur di GitHub

Buka fork lo, navigate ke `showcase/kernal/`. Pastikan ada:
```
showcase/kernal/showcase.json     ✅
showcase/kernal/README.md         ✅
showcase/kernal/soul.md           ✅
showcase/kernal/examples/         ✅ (2 file)
showcase/kernal/skills/           ✅ (11 folder, masing-masing ada SKILL.md)
```

Kalau ada yang nyasar (misal ada `kernal/kernal/...` dobel), hapus yang salah dan ulangi. Struktur harus persis `showcase/kernal/<file>`.

---

## LANGKAH 5 — Cek PR #29 auto-update

1. Buka PR #29: https://github.com/Virtual-Protocol/acp-cli-demos/pull/29
2. Tab **Files changed** — harusnya sekarang semua file ada di bawah `showcase/kernal/`
3. Scroll ke bawah, cek bagian **checks** — tunggu validator (CI) jadi hijau ✅
   - Kalau merah: klik "Details", screenshot error-nya, kasih ke Claude (aku) buat dibetulin

---

## LANGKAH 6 — Balas komentar @ytoast

Di PR #29, tab **Conversation**, balas komentar @ytoast:

```
Thanks for the review! Done on both:

1. Moved everything under `showcase/kernal/` so it reflects correctly in the community showcase.
2. Added a `README.md` explaining KERNAL, the full offering catalog, and links to the agent + live demo.

While I was at it I also added the reusable skills (11 SKILL.md files, one per offering), an `examples/` folder with a real hire prompt + redacted result, and a `soul.md` with public agent context. Manifest passes `node scripts/validate-showcase.mjs`. Let me know if anything else is needed!
```

---

## SELESAI

Setelah ini, tinggal nunggu @ytoast review lagi + approve + merge. Setelah merge, card KERNAL muncul di https://os.virtuals.io/community#showcase

---

## KALAU NYANGKUT

- **Bingung mindahin file yang salah** → screenshot tab "Files changed" di PR #29, kasih ke aku
- **Validator merah** → screenshot error, kasih ke aku
- **Struktur folder kacau pas upload** → hapus semua di `showcase/kernal/`, ulangi Langkah 3 dengan folder `kernal` yang udah rapi
- **Upload folder ga jalan di browser** → pakai Chrome/Edge (drag folder paling reliable di situ), atau upload per-folder (skills/ dulu, terus examples/, terus file root)

---

*Semua file: kernal-showcase-files.zip*
*Target: showcase/kernal/ di Virtual-Protocol/acp-cli-demos (via fork gitkernal)*
*PR: #29*
